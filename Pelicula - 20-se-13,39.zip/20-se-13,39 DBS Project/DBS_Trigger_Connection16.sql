create or replace NONEDITIONABLE TRIGGER Login_After_Insert
AFTER INSERT
 ON P_User
 FOR EACH ROW
DECLARE
l_username varchar2(32);
BEGIN
SELECT user INTO l_username
 FROM dual;
 INSERT INTO User_Login_Information
(Username, 
User_Name, 
User_Password, 
User_DOB,
login_by,
create_date)
 VALUES
 (:new.Username,
 :new.User_Name,
 :new.User_Password,
 :new.User_DOB,
 l_username,
 sysdate);
END;