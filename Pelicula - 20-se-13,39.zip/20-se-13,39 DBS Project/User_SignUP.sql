create or replace NONEDITIONABLE PROCEDURE AddUser(username VARCHAR2, name VARCHAR2, dateOfBirth VARCHAR2, password VARCHAR2)
AS
BEGIN
INSERT INTO P_USER (Username, User_Name, User_DOB, User_Password) VALUES (username, name, dateOfBirth, password);
COMMIT;
END;

