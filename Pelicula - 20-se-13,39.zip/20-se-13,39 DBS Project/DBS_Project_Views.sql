CREATE OR REPLACE VIEW SHOW_USER_VIEW AS
SELECT TVShow_Name, Release_Year, Age_Rating, No_Of_Seasons, Genre, TVShow_Description
FROM TVShow;

CREATE OR REPLACE VIEW MOVIE_USER_VIEW AS
SELECT Movie.Movie_Name, Movie.Release_Date, Movie.Genre, Movie.Age_Rating, Movie.Imdb_Rating, Movie.Movie_Poster, Movie.Movie_Description, 
       Distributor.Distributor_Name, Distributor.Distributor_Link,
       Actor.Actor_Name
FROM Movie
FULL OUTER JOIN ACTOR
ON ACTOR.MOVIEID = MOVIE.MOVIE_ID
FULL OUTER JOIN DISTRIBUTOR
ON MOVIE.DISTRIBUTORID=DISTRIBUTOR.DISTRIBUTOR_ID;
