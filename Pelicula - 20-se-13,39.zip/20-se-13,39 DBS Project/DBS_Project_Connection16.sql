CREATE TABLE Movie
(
Movie_ID VARCHAR2(50) PRIMARY KEY, 
Movie_Name VARCHAR(150), 
Release_Date VARCHAR2(20),
Genre VARCHAR(100),
Age_Rating VARCHAR(30),
Imdb_Rating NUMBER(4, 2),
Movie_Poster VARCHAR2(1000), 
Movie_Description VARCHAR2(1000),
DistributorID NUMBER(5),
CONSTRAINT DistributorID_FK FOREIGN KEY (DistributorID) REFERENCES Distributor (Distributor_ID)
);

CREATE TABLE Actor
(
Actor_ID NUMBER(5) PRIMARY KEY, 
Actor_Name VARCHAR2(32),
MovieID VARCHAR(32),
CONSTRAINT MovieID_FK1 FOREIGN KEY (MovieID) REFERENCES Movie (Movie_ID)
);

CREATE TABLE Distributor
(
Distributor_ID NUMBER(5) PRIMARY KEY, 
Distributor_Name VARCHAR(50), 
Distributor_Link VARCHAR2(50)
);

CREATE TABLE P_User
(
Username VARCHAR(32) PRIMARY KEY, 
User_Name VARCHAR(32), 
User_Password VARCHAR(32), 
User_DOB VARCHAR(32)
);


CREATE TABLE TVShow
(
TVShow_ID VARCHAR2(50) PRIMARY KEY, 
TVShow_Name VARCHAR(150), 
Release_Year NUMBER(5),
Age_Rating VARCHAR(30),
No_Of_Seasons VARCHAR(30),
Genre VARCHAR(100),
TVShow_Description VARCHAR2(1000)
);

CREATE TABLE User_Login_Information(
Username VARCHAR(32), 
User_Name VARCHAR(32), 
User_Password VARCHAR(32), 
User_DOB VARCHAR(32),
login_by VARCHAR(32),
create_date date
);
